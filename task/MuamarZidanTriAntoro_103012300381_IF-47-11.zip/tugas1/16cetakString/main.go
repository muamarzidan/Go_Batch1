package main

import (
	"fmt"
)


//soal no 16
func main() {
	var namaSaya string

	fmt.Print("Masukkan nama : ")
	fmt.Scan(&namaSaya)

	fmt.Println("Hai, " + namaSaya)
}