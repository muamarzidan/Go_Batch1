package main

import "fmt"

func main() {
	fmt.Println("NAMA : Muamar Zidan Tri Antoro")
	fmt.Println("NIM : 103012300381")
	fmt.Println("KELAS : IF-47-11")
}
